function detail(){
    let secProfile = document.getElementById("sec_profile")
    let moreDetail = document.getElementById("new_details")

    moreDetail.style.display = "block"
    // secProfile.style.height = (String)(secProfile.offsetHeight + moreDetail.offsetHeight)
}